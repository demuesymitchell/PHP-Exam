<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation(basename($_SERVER['PHP_SELF'])); ?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  

	***Humor is always welcome ~ but keep it appropriate ;) ***
	
	Step 1: Create a loop to display 10 numbers starting with your age, my list would start with 61


	Step 2 : Find the errors in this code:
	
		/* <! php <-- The PHP Tag isn't correct. It should be "<?php"
		      print 'Good morning, how are you?' <-- The print function isn't correct. It should be closed in by single or double quotes.
			  pring 'I'm fine' <-- Pring should be "print" // "I'm fine" should be enclosed in quotes.
			> <-- Closing PHP tag should be "?>"
		*/

	//Step 1
	
	$myAge = 61;
	for ($i = $myAge; $i < $myAge + 10; $i++) {
		echo "Number: $i<br>";
	}
	
	//Step 2 Is corrected within the notes.
	
?>






</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>