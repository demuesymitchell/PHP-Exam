<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation(basename($_SERVER['PHP_SELF'])); ?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  

	***Humor is always welcome ~ but keep it appropriate ;) ***
	
	Step 1: Create a web page that places the following data inside a table.  Names, James, Mary, Matthew, Zachary, Jane ~ Monthly Salary, 5000, 5500, 6500, 7700, 9800 
	Step 2: Create a calculatation that displays each person's "Annual Salary".



 */

	// Step 1 & Step 2 combined.
	
	$names = array("James", "Mary", "Matthew", "Zachary", "Jane");
	$monthlySalaries = array(5000, 5500, 6500, 7700, 9800);
	
	echo "<table border='1'>
            <tr>
                <th>Name</th>
                <th>Monthly Salary</th>
                <th>Annual Salary</th>
            </tr>";

        for ($i = 0; $i < count($names); $i++) {
            $name = $names[$i];
            $monthlySalary = $monthlySalaries[$i];
            $annualSalary = $monthlySalary * 12;

            echo "
				<tr>
                <td>$name</td>
                <td>$monthlySalary</td>
                <td>$annualSalary</td>
            </tr>";
        }
		
		echo "</table>";
		
		
		
		
?>






</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>