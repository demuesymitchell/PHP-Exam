<!-- Mitchell DeMuesy
	Exam 2 11/15/2023 -->
<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  

	***Humor is always welcome ~ but keep it appropriate ;) ***
	
	Step 1: Write a program to find the square of the first 10 numbers using a for loop
	
	Step 2: Make sure the page is formatted beautifully
	
		 *  The finished page should include the following to receive full credit:
				*  Comments  / name, date, description
				*  Header
				*  Print the number and answer to a web page
				*  Incorporate CSS, this will make or break the interview process! ;)
				

	
*/

		echo "<h2>Square of the First 10 Numbers</h2>";

        for ($i = 1; $i <= 10; $i++) {
            $square = $i * $i;
            echo "<p>The square of $i is: $square</p>";
        }

        ?>




</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>