<!-- Mitchell DeMuesy
	Exam 2 11/15/2023 -->
<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  

	***Humor is always welcome ~ but keep it appropriate ;) ***
	
	Step 1: Using the if-else statement, write a program to find whether 53 is an even or odd
	
	Step 2: Make sure the page is formatted beautifully
	
		 *  The finished page should include the following to receive full credit:
				*  Comments  / name, date, description
				*  Header
				*  Print the number and answer to a web page
				*  Incorporate CSS, this will make or break the interview process! ;)
				
	Step 3: Create a program associated with Math that uses the if-else statement
				

	
*/

		// Step 1: Check if 53 is even or odd
        $number = 53;

        echo "<h2>Is $number Even or Odd?</h2>";

        if ($number % 2 == 0) {
            echo "<p>$number is even.</p>";
        } else {
            echo "<p>$number is odd.</p>";
        }

        // Step 3: Create a program associated with Math
        // Random number
        $randomNumber = rand(-10, 10);

        echo "<h2>Number Analysis</h2>";
        echo "<p>The randomly generated number is: $randomNumber</p>";

        if ($randomNumber > 0) {
            echo "<p>The number is positive.</p>";
        } elseif ($randomNumber < 0) {
            echo "<p>The number is negative.</p>";
        } else {
            echo "<p>The number is zero.</p>";
        }

        ?>




</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>