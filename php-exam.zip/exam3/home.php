<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>

	<div id="navigation">

		<?php 

		include "functions.php";

		Navigation();


		 ?>
		
	</div>

	<div id="content">

	</div>



	
</body>
</html>

