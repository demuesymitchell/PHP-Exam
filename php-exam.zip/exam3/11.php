<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  

	It's your turn to make a difference in this course.  Create an exercise for Exam 3 that every student should be able to complete based on the materials covered in this course.
	
	Not every submission will earn 50pts, only the submissions that have a challenging exercise along with proof that the code functions properly (solution).
	
	The exercise must not be a duplicate of an exercise used within the course; must be school appropriate material; most of all, related to PHP.
	
	Please feel free to work with a coding buddy on this activity.
	
	Those submissions that earn 100% will more than likely be used in future semesters as "extra-credit exercises, quizzes, etc.".  If permitted, your name will be used as the "author" of the exercise, for example:  "Master Coder, Bugs Bunny, created this exercise for you, are you up to the challenge?"
	
	
*/

?>

<!-- So, it took me some time to try to create a unique approach to an exercise that we haven't quite worked on. 
	Most of whats in this exercise is from topics that we covered(forms and scripts). The only addition that I made was using the function of 'strrev'. 
	I'm sure you're familiar with this function, but it introduces a new and unique function for a form entry exercise that you could introduce early on within' the course! -->
	
<!-- Requirements
	
	1. Create an HTML Form with an input field to retrieve the student's selected word!
	2. Create a script that reverses the entered word.
	3. Display the reversed word on the page!
	
	-->
	
<!-- The goal of this exercise isn't meant to be very challenging but instead introduce further practice with forms and scripts! -->
	

<form method="post" action="">
    <label for="word">Enter a word! :</label>
    <input type="text" name="word" required>
    <input type="submit" value="Reverse Word">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the user's entered word from what they entered.
    $word = $_POST["word"];

    // Reverse the word! Then display it reversed.
    $reverse = strrev($word);
    echo "<p>Reversed Word: $reverse</p>";
}
?>



</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>