<!-- Mitchell DeMuesy
	Exam 2 11/15/2023 -->

<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  

	***Humor is always welcome ~ but keep it appropriate ;) ***
	
	
<?php
$rand1=rand();
$rand2=rand(15,25);
$rand3=rand(-150,300);
echo "Random number without a range : ". $rand1 . "<br />";
echo "Random number between 15 to 25  is " . $rand2 . "<br />";
echo "Random number between -150 to 300  is " . $rand3 . "<br />";
?>

rand() used in a game

// this represents the partial html code

<form action="guess.php" method="POST">
Guess a Number Between 1 and 10: 
<input type="number" name="guess" value=''> 
<br><br>
<input type="submit" name="submit" value="Guess">
<br><br>
</form>

// complete  the guess.php code; replace any occurrence of ??


$randomNumber= rand(1, 10);

$guess = $_POST['guess'];

$submit = $_POST['submit'];

if(isset($submit))
{
	if (( ?? > 0) && ( ?? < 11))
	{
		if ($guess != ??)
{
?? "Incorrect guess. The correct number was . Try again";
}
}

??
{
	?? "$randomNumber is the correct guess. You got it right.";
}
}

	
		 *  The finished page should include the following to receive full credit:
				*  Comments  / name, date, description
				*  Incorporate CSS, this will make or break the interview process! ;)
				*  Make sure the html and php files contain the correct code to function like a guessing game
				*  Modify the code to make it unique
				

	
*/

		// Generate a random number between 1 and 10
        $randomNumber = rand(1, 10);

        // Check if the form is submitted
        if (isset($_POST['submit'])) {
            // Get the user's guess from the form
            $guess = $_POST['guess'];

            // Check if the guess is within the valid range (1 to 10)
            if ($guess > 0 && $guess < 11) {
                // Check if the guess is correct
                if ($guess != $randomNumber) {
                    echo "Incorrect guess. The correct number was $randomNumber. Try again.";
                } else {
                    echo "$randomNumber is the correct guess. You got it right!";
                }
            }
        }
        ?>

        <!-- HTML form for the guessing game -->
        <form action="8.php" method="POST">
            <label for="guess">Guess a Number Between 1 and 10:</label>
            <input type="number" name="guess" value=''>
            <br><br>
            <input type="submit" name="submit" value="Guess">
            <br><br>
        </form>




</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>