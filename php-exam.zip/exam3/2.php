<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

		<aside class="col-xs-4">

	<?php Navigation(basename($_SERVER['PHP_SELF'])); ?>
			
			
		</aside><!--SIDEBAR-->


		<article class="main-content col-xs-8">
		


		<?php
		
		
		/*
		
		***Humor is always welcome ~ but keep it appropriate ;) ***
		
		Step 1: Create 2 variables called number1 and number2 and set 1 to value 110 and the other 220:

		Step 2: Add the two variables and display the sum with echo:

		Step3: Create an array of your favorite childhood candies, display them in any order you desire

		Step4: Demonstrate an example of using a constant
		
		*/
		
		//Step 1

		$number1 = 110;
		$number2 = 220;
		
		//Step 2
		$sum = $number1 + $number2;
		echo "The sum of $number1 and $number2 is: $sum<br>";
		
		//Step 3
		
		$favoriteCandies = array("Kit Kat", "Snickers", "Sour Patch Kids</br>");
		echo "My favorite childhood candies: " . implode(", ", $favoriteCandies);
		
		//Step 4
		
		define("GREETING", "Hello, World!");
		echo GREETING;
		
		?>


		</article><!--MAIN CONTENT-->

<?php include "includes/footer.php" ?>