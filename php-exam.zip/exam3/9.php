<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation();?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  
	1)  Create a php file that connects to a database using PDO (PHP Data Objects).
	2)  Provide a brief summary of your thoughts about this type of connection.
	3)  Create a php file that connects to a database using an Object-Oriented approach.
	4)  Provide a brief summary of your thoughts about this type of connection.
	
*/


/* STEP 1 - PDO CONNECTION */

try {
    $pdo = new PDO("mysql:host=sql201.infinityfree.com;dbname=if0_35310369_guestbook", "if0_35310369", "xrBuZDhHq6jh");
    
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "Connected successfully - PDO Connection";
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

/* STEP 2 - SUMMARY */

echo "<br><br>";
echo "PDO is a way to access multiple databses! It is claimed to be a more secure approach to connect. From what I researched it reduces the risk of SQL injection. It also supports a variety of database systems which is great.";
echo "<br>";

/* STEP 3 - Object-Oriented Connection */

$host = "sql201.infinityfree.com";
$username = "if0_35310369";
$password = "xrBuZDhHq6jh";
$database = "if0_35310369_guestbook";

$dbc = new mysqli($host, $username, $password, $database);

// Check connection
if ($dbc->connect_error) {
    die("Connection failed: " . $dbc->connect_error);
}
echo "<br>";
echo "Connected successfully - Object-Oriented connection";


/* STEP 4 - SUMMARY */
echo "<br><br>";
echo "Object-Oriented connection using mysqli is a simple way to connect to a MySQL database ! I find this method to be very straight forward and easy to learn when first working on this topic.";


?>


</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>