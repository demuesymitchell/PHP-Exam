<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation(basename($_SERVER['PHP_SELF'])); ?>
			
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">
		


		<?php  


		/* 
		***Humor is always welcome ~ but keep it appropriate ;) ***
		
		   Step 1:  Use the echo Function to say hello, or some other school appropriate phrase with html h1 tags embedded inside php.
		   
		   Step 2: Write a comment above the echo function and explain what that function is doing.

		 */
		 
		 // The echo function is used to display the message.
		 
		 echo "<h1>Hello, World!</h1>"; 

		?>

	

		</article><!--MAIN CONTENT-->

<?php include "includes/footer.php" ?>