<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

		<aside class="col-sm-4">
		
		<?php Navigation();?>
			
		</aside><!--SIDEBAR-->

		<article class="main-content col-sm-8">

			<h3>PHP Activities</h3>
			
<p>Provide a few words about what this site is about.</p>

<p>Share a few words about your PHP progress.</p>


		</article><!--MAIN CONTENT-->

			

<?php include "includes/footer.php" ?>
			
			



