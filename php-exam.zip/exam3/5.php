<?php include "functions.php" ?>
<?php include "includes/header.php" ?>

	<section class="content">

	<aside class="col-xs-4">

	<?php Navigation(); ?>
			
	</aside><!--SIDEBAR-->


<article class="main-content col-xs-8">

<?php  

/*  

	***Humor is always welcome ~ but keep it appropriate ;) ***
	
	Step 1: Create a PHP program that computes the total cost of this meal (feel free to modify menu items):
	
	     *  hamburger ~ $4.95  (you were hungry so you ate 2 of them!)
		 *  chocolate shake ~ $1.95 (flavor price all of the same)
		 *  soda ~ $.85 (refills are free)
		 *  sals tax rate ~ 7.5%
		 *  pre-tax tip ~ 16%  
	
	Step 2: Make sure the page is formatted beautifully
	
		 *  The finished page should include the following to receive full credit:
				*  Comments  / name, date, description
				*  Header
				*  Details about the menu items / show each item along with corresponding price
				*  Sub total of meal before tax and tip
				*  Total which includes meal cost, tax, and tip
				*  Incorporate CSS, this will make or break the interview process! ;)
				
	The image is a guide only, your submission will be amazing!
	*helpful code for total ~ echo "The cost of my meal, including tax and tip:  " . "$". round($total,2);
	
*/

		// Menu item prices
        $hamburgerPrice = 4.95;
        $chocolateShakePrice = 1.95;
        $sodaPrice = 0.85;

        // Number of items consumed
        $numHamburgers = 2;
        $numChocolateShakes = 1;
        $numSodas = 1;

        // Tax and tip rates
        $taxRate = 0.075;
        $tipRate = 0.16;

        // Calculate subtotal
        $subtotal = ($numHamburgers * $hamburgerPrice) + ($numChocolateShakes * $chocolateShakePrice)
		+ ($numSodas * $sodaPrice);

        // Calculate tax and tip
        $tax = $subtotal * $taxRate;
        $tip = $subtotal * $tipRate;

        // Calculate total cost
        $total = $subtotal + $tax + $tip;

        // Display the details
        echo "<h2>Menu Items and Prices</h2>";
        echo "<p>Hamburger (2x) - \$$hamburgerPrice each</p>";
        echo "<p>Chocolate Shake (1x) - \$$chocolateShakePrice each</p>";
        echo "<p>Soda (1x) - \$$sodaPrice each</p>";

        echo "<h2>Subtotal</h2>";
        echo "<p>Meal cost before tax and tip: \$$subtotal</p>";

        echo "<h2>Total</h2>";
        echo "<p>The cost of my meal, including tax and tip: \$$total</p>";

        ?>




</article><!--MAIN CONTENT-->
	
<?php include "includes/footer.php" ?>